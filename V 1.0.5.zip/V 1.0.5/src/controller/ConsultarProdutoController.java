package controller;

import bancoDeDados.ProdutosDAO;
import model.Produtos;
import view.paineis.PainelConsultarProdutos;

public class ConsultarProdutoController {

	private final PainelConsultarProdutos viewConsultaProdutos;

	/**
	 * Construtor de comunicacao com o PainelConsultaProdutos (view)
	 * @param viewConsultarProdutos - variavel do tipo PainelConsultarProdutos para controle da tela
	 */
	public ConsultarProdutoController(PainelConsultarProdutos viewConsultaProdutos) {
		this.viewConsultaProdutos = viewConsultaProdutos;
	}

	/**
	 * Metodo que aciona uma busca a partir do codigo do produto no banco de dados
	 * @return mensagem - com o resultado para o usuário
	 */
	public String pesquisarProduto() {
		String mensagem;
		try {
			int codigo = Integer.parseInt(viewConsultaProdutos.getTxtCodProduto().getText());

			Produtos produto = new Produtos(codigo);

			ProdutosDAO produtoDAO = new ProdutosDAO();

			produtoDAO.pesquisarProdutoBanco(produto);

			if(produtoDAO.pesquisarProdutoBanco(produto)!=null) {
				viewConsultaProdutos.getTxtCodProduto().setText(Integer.toString(produto.getCodigoProduto()));
				viewConsultaProdutos.getTxtNome().setText(produto.getNome());
				viewConsultaProdutos.getTxtDescricao().setText(produto.getDescricao());
				viewConsultaProdutos.getTxtUnidadeMedida().setText(produto.getUnidadeMedida());
				viewConsultaProdutos.getTxtValorUnitario().setText(Double.toString(produto.getValorUnitario()));
				mensagem = "Produto encontrado!";
			}
			else {
				mensagem = "Ocorreu um erro ao buscar o Produto!";
			}
		}
		catch(NumberFormatException erro) {
			mensagem = "Por favor digite um código válido!";
		}
		return mensagem;
	}

	/**
	 * Metodo para alterar os estados dos campos da tela e buscar um produto através do código para ser editado
	 * @return mensagem - com o resultado para o usuário
	 */
	public String liberarEdicao() {
		String mensagem;
		pesquisarProduto();
		if(pesquisarProduto().equals("Produto encontrado!")) {
			viewConsultaProdutos.getBtnSalvar().setVisible(!viewConsultaProdutos.getBtnSalvar().isVisible());
			viewConsultaProdutos.getTxtNome().setEditable(!viewConsultaProdutos.getTxtNome().isEditable());
			viewConsultaProdutos.getTxtCodProduto().setEditable(!viewConsultaProdutos.getTxtCodProduto().isEditable());
			viewConsultaProdutos.getTxtDescricao().setEditable(!viewConsultaProdutos.getTxtDescricao().isEditable());
			viewConsultaProdutos.getTxtUnidadeMedida().setEditable(!viewConsultaProdutos.getTxtUnidadeMedida().isEditable());
			viewConsultaProdutos.getTxtValorUnitario().setEditable(!viewConsultaProdutos.getTxtValorUnitario().isEditable());

			mensagem = "Entrando em cadastro para edição!";
		}
		else {
			mensagem = "Foi encontrado um erro ao entrar no modo de edicão!";
		}
		return mensagem;
	}

	/**
	 * Método que aciona a atualização do cadastro de um produto no banco de dados através do codigo na tela
	 * @return mensagem - com o resultado para o usuário
	 */
	public String atualizarProduto() {
		String mensagem;
		try {
			int codigo = Integer.parseInt(viewConsultaProdutos.getTxtCodProduto().getText());
			String nome = viewConsultaProdutos.getTxtNome().getText();
			String descricao = viewConsultaProdutos.getTxtDescricao().getText();
			Double valorUnitario = Double.parseDouble(viewConsultaProdutos.getTxtValorUnitario().getText());
			String unidadeMedida = viewConsultaProdutos.getTxtUnidadeMedida().getText();
			if(nome.length()==0) {
				mensagem = "É obrigatório informar um nome para o produto!"; //Conforme RN12
			}
			else if(descricao.length()==0) {
				mensagem = "É obrigatório informar uma descrição para o produto!"; //Conforme RN12
			}
			else if(valorUnitario<=0) {
				mensagem = "Por favor digite um valor unitário valido!"; //Conforme RN12
			}
			else if(unidadeMedida.length()==0) {
				mensagem = "É obrigatório informar uma unidade de medida para o produto!"; //Conforme RN12
			} 
			else {
				Produtos produto = new Produtos(codigo, nome, valorUnitario, descricao, unidadeMedida);

				ProdutosDAO produtoDAO = new ProdutosDAO();

				mensagem = produtoDAO.atualizarProdutoBanco(produto);
			}
		}
		catch(NumberFormatException erro) {
			mensagem = "Por favor digite um valor unitário valido!";
		}
		return mensagem;
	}

}

