package controller;


import bancoDeDados.ServicosDAO;

import model.Servico;

import view.paineis.PainelCadastrarServico;

public class CadastrarServicoController {

	private final PainelCadastrarServico viewCadastroServico;
	
	/**
	 * Construtor de comunicacao com o PainelCadastroServico (view)
	 * @param viewCadastroServico - variavel do tipo PainelCadastroServico para controle da tela
	 */
	public CadastrarServicoController(PainelCadastrarServico viewCadastroServico) {
		this.viewCadastroServico = viewCadastroServico;
	}
	/**
	 * Metodo que busca os valores digitados na tela de cadastro de servicos e aciona o metodo para salvar o servico no banco de dados
	 * @return mensagem - retorna mensagem do tipo String para o usuário
	 */
	public String salvarServico() {
		String mensagem;
		try {
			String nome = viewCadastroServico.getTxtNome().getText();
			String descricao = viewCadastroServico.getTxtDescricao().getText();
			Double valor = Double.parseDouble(viewCadastroServico.getTxtValor().getText());

			if(nome.length()==0) {
				mensagem = "É obrigatório informar um nome para o serviço!"; //Conforme RN12
			}
			else if(descricao.length()==0) {
				mensagem = "É obrigatório informar uma descrição para o serviço!"; //Conforme RN12
			}
			else if(valor<=0) {
				mensagem = "Por favor digite um valor valido!"; //Conforme RN12
			}
			else {

				Servico Servico = new Servico(nome, descricao, valor);

				ServicosDAO ServicoDAO = new ServicosDAO();

				mensagem = ServicoDAO.salvarServicoBanco(Servico);
			}
		}
		catch(NumberFormatException erro) {
			mensagem = "Por favor digite um valor valido!";
		}
		return mensagem;
	}
	
	/**
	 * Método para limpar os dados na tela
	 */
	public void limpar() {
		viewCadastroServico.getTxtNome().setText("");
		viewCadastroServico.getTxtDescricao().setText("");
		viewCadastroServico.getTxtValor().setText("");
	}

}
