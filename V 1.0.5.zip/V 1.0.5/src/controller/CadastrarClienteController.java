package controller;

import bancoDeDados.ClientesDAO;
import model.Clientes;
import view.paineis.PainelCadastrarClientes;

public class CadastrarClienteController {
	private final PainelCadastrarClientes viewCadastroClientes;
	
	/**
	 * Construtor de comunicacao com o PainelCadastrarClientes (view)
	 * @param viewCadastroClientes - variavel do tipo PainelCadastrarClientes para controle da tela
	 */
	public CadastrarClienteController(PainelCadastrarClientes viewCadastroClientes) {
		this.viewCadastroClientes = viewCadastroClientes;
	}
	
	/**
	 * Metodo que busca os valores digitados na tela de cadastro de cliente e aciona o metodo para salvar cliente no banco de dados
	 * @return mensagem - retorna uma mensagem do tipo String para o usuário 
	 */
	public String salvarCliente() {
		
		String mensagem;
		
		String nome = viewCadastroClientes.getTxtNome().getText();
		String endereco = viewCadastroClientes.getTxtEndereco().getText();
		String telefone = viewCadastroClientes.getTxtTelefone().getText();
		String cidade = viewCadastroClientes.getTxtCidade().getText();
		String email = viewCadastroClientes.getTxtEmail().getText();
		String doc = viewCadastroClientes.getTxtDoc().getText();
		String pessoaJuridica = (String) viewCadastroClientes.getListaPjuridica().getSelectedItem();
		
		if(pessoaJuridica.equals("Não") && (doc.length()>11 || doc.length()<11)) {
			mensagem = "O CPF deve conter 11 digitos!"; //Conforme RN05
		}
		else if (pessoaJuridica.equals("Sim") && (doc.length()>14 || doc.length()<14)) {
			mensagem = "O CNPJ deve conter 14 digitos!"; //Conforme RN04
		}
		else if(nome.length()<=0) {
			mensagem = "O nome do cliente é um campo obrigatório!"; //Conforme RN011
		}
		else {
		Clientes cliente = new Clientes(nome, doc, email, telefone, endereco, cidade, pessoaJuridica);
		
		ClientesDAO clienteDAO = new ClientesDAO();
		
		mensagem = clienteDAO.salvarClientesBanco(cliente);}
		
		return mensagem;
	}
	
	/**
	 * Metodo para limpar os campos da tela
	 */
	public void limpar() {
		viewCadastroClientes.getTxtNome().setText("");
		viewCadastroClientes.getTxtTelefone().setText("");
		viewCadastroClientes.getTxtEndereco().setText("");
		viewCadastroClientes.getTxtCidade().setText("");
		viewCadastroClientes.getTxtEmail().setText("");
		viewCadastroClientes.getTxtDoc().setText("");

		
	}
	
}
