package controller;


import bancoDeDados.FuncionarioDAO;
import model.Funcionarios;
import view.paineis.PainelCadastrarFuncionarios;

public class CadastrarFuncionarioController {
	
	private final PainelCadastrarFuncionarios viewCadastrarFuncionarios;
	/**
	 * Construtor de comunicacao com o PainelCadastrarFuncionarios (view)
	 * @param viewCadastrarFuncionario - variavel do tipo PainelCadastrarFuncionarios para controle da tela
	 */
	public CadastrarFuncionarioController(PainelCadastrarFuncionarios viewCadastrarFuncionarios) {
		this.viewCadastrarFuncionarios = viewCadastrarFuncionarios;
	}
	
	/**
	 * Metodo que busca os valores digitados na tela de cadastro de funcionarios e aciona o metodo para salvar funcionario no banco de dados
	 * @return mensagem - retorna uma mensagem do tipo String para o usuário 
	 */
	public String salvarFuncionario() {
		
		String mensagem;
		
		String nome = viewCadastrarFuncionarios.getTxtNome().getText();
		String documento = viewCadastrarFuncionarios.getTxtCpf().getText();
		String email = viewCadastrarFuncionarios.getTxtEmail().getText();
		String telefone = viewCadastrarFuncionarios.getTxtTelefone().getText();
		String endereco = viewCadastrarFuncionarios.getTxtEndereco().getText();
		String cidade = viewCadastrarFuncionarios.getTxtCidade().getText();
		String cargo = viewCadastrarFuncionarios.getTxtCargo().getText();
		String login = viewCadastrarFuncionarios.getTxtLogin().getText();
		String senha = viewCadastrarFuncionarios.getTxtSenha().getText();
		
		if(documento.length()>11||documento.length()<11) {
			mensagem = "O CPF deve conter 11 digitos!"; //Conforme RN05 e RN12
		}
		
		else if(senha.length()<8) {
			mensagem = "A senha deve conter pelo menos 8 digítos!"; //Conforme RN08 e RN12 
		}
		else if(login.length()<=0) {
			mensagem = "É obrigatório informar um login!"; //Conforme RN12
		}
		else if(nome.length()<=0) {
			mensagem = "É obrigatório informar o nome do funcionário!"; //Conforme RN12
		}
		else if(email.length()<=0) {
			mensagem = "É obrigatório informar o email do funcionário!"; //Conforme RN12
		}
		else if(telefone.length()<=0) {
			mensagem = "É obrigatório informar o telefone do funcionário!"; //Conforme RN12
		}
		else if(endereco.length()<=0) {
			mensagem = "É obrigatório informar o endereco do funcionário!"; //Conforme RN12
		}
		else if(cidade.length()<=0) {
			mensagem = "É obrigatório informar a cidade do funcionário!"; //Conforme RN12
		}
		else if(cargo.length()<=0) {
			mensagem = "É obrigatório informar um cargo para o funcionário"; //Conforme RN12
		}
		else {
			Funcionarios funcionario = new Funcionarios(nome, documento, telefone, endereco, email, cidade, cargo, login, senha);
			
			FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
			
			mensagem = funcionarioDAO.salvarFuncionarioBanco(funcionario);
		
		}
		return mensagem;
	}
	
	/**
	 * Limpa os campos da tela
	 */
	public void limpar() {
		viewCadastrarFuncionarios.getTxtNome().setText("");
		viewCadastrarFuncionarios.getTxtCpf().setText("");
		viewCadastrarFuncionarios.getTxtEmail().setText("");
		viewCadastrarFuncionarios.getTxtTelefone().setText("");
		viewCadastrarFuncionarios.getTxtEndereco().setText("");
		viewCadastrarFuncionarios.getTxtCidade().setText("");
		viewCadastrarFuncionarios.getTxtCargo().setText("");
		viewCadastrarFuncionarios.getTxtLogin().setText("");
		viewCadastrarFuncionarios.getTxtSenha().setText("");
		
	}
	
}
