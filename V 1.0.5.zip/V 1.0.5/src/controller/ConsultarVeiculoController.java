package controller;

import bancoDeDados.ClientesDAO;
import bancoDeDados.VeiculosDAO;
import model.Clientes;
import model.Veiculos;
import view.paineis.PainelConsultarVeiculos;

public class ConsultarVeiculoController {

	private final PainelConsultarVeiculos viewConsultaVeiculos;

	/**
	 * Construtor de comunicacao com o PainelConsultarVeiculos (view)
	 * @param viewConsultaVeiculos - variavel do tipo PainelConsultarVeiculos para controle da tela
	 */
	public ConsultarVeiculoController(PainelConsultarVeiculos viewConsultaVeiculos) {
		this.viewConsultaVeiculos = viewConsultaVeiculos;
	}

	/**
	 * Metodo que aciona uma busca no banco de dados por todos os clientes cadastrados
	 * @return listaClientes - retorna um array com todos os veiculos encontrados
	 */
	public String[] listarClientes() {
		ClientesDAO clienteDAO = new ClientesDAO();
		String[] listaClientesAtivos = clienteDAO.listarClientes();
		return listaClientesAtivos;
	}

	/**
	 * Metodo que aciona uma busca a partir do codigo do veiculo no banco de dados
	 * @return mensagem - com o resultado para o usuário
	 */
	public String pesquisarVeiculo() {
		String mensagem;
		try {
			int codigo = Integer.parseInt(viewConsultaVeiculos.getTxtCodVeiculo().getText());

			Veiculos veiculo = new Veiculos(codigo);

			VeiculosDAO veiculoDAO = new VeiculosDAO();

			veiculoDAO.pesquisarVeiculoBanco(veiculo);

			if(veiculoDAO.pesquisarVeiculoBanco(veiculo)!=null) {
				viewConsultaVeiculos.getTxtCodVeiculo().setText(Integer.toString(veiculo.getCodigoVeiculo()));
				viewConsultaVeiculos.getTxtCor().setText(veiculo.getCor());
				viewConsultaVeiculos.getTxtMarca().setText(veiculo.getMarca());
				viewConsultaVeiculos.getTxtModelo().setText(veiculo.getModelo());
				viewConsultaVeiculos.getTxtPlaca().setText(veiculo.getPlaca());
				viewConsultaVeiculos.getTxtAno().setText(Integer.toString(veiculo.getAno()));
				viewConsultaVeiculos.getListaAtivo().setSelectedItem(veiculo.getAtivo());

				String codigoCliente = Integer.toString(veiculo.getCliente().getCodigoCliente()); // Recebe o codigo do cliente para buscar na lista
				for (int i = 0; i < viewConsultaVeiculos.getListaCliente().getItemCount(); i++) { // 
					String item = (String) viewConsultaVeiculos.getListaCliente().getItemAt(i); // Obtém o item atual e converte para String.
					if (item.startsWith(codigoCliente)) { // Verifica se o item  começa com o codigo
						viewConsultaVeiculos.getListaCliente().setSelectedItem(item); // Se sim, seleciona o item atual usando o índice i.
						break; // Encerra o loop, já que encontrou o item desejado.
					}
				}
				mensagem = "Veiculo encontrado!";
			}
			else {
				mensagem = "Ocorreu um erro ao buscar o veiculo!";
			}
		}
		catch(NumberFormatException erro) {
			mensagem = "Por favor digite um código válido!";
		}
		return mensagem;
	}

	/**
	 * Metodo para alterar os estados dos campos da tela e buscar um veículo através do código para ser editado
	 * @return mensagem - com o resultado para o usuário
	 */
	public String liberarEdicao() {
		String mensagem;
		pesquisarVeiculo();
		if(pesquisarVeiculo().equals("Veiculo encontrado!")) {
			viewConsultaVeiculos.getBtnSalvar().setVisible(!viewConsultaVeiculos.getBtnSalvar().isVisible());
			viewConsultaVeiculos.getTxtCodVeiculo().setEditable(!viewConsultaVeiculos.getTxtCodVeiculo().isEditable());
			viewConsultaVeiculos.getTxtAno().setEditable(!viewConsultaVeiculos.getTxtAno().isEditable());
			viewConsultaVeiculos.getTxtCor().setEditable(!viewConsultaVeiculos.getTxtCor().isEditable());
			viewConsultaVeiculos.getTxtMarca().setEditable(!viewConsultaVeiculos.getTxtMarca().isEditable());
			viewConsultaVeiculos.getTxtModelo().setEditable(!viewConsultaVeiculos.getTxtModelo().isEditable());
			viewConsultaVeiculos.getTxtPlaca().setEditable(!viewConsultaVeiculos.getTxtPlaca().isEditable());
			viewConsultaVeiculos.getListaAtivo().setEnabled(!viewConsultaVeiculos.getListaAtivo().isEnabled());
			viewConsultaVeiculos.getListaCliente().setEnabled(!viewConsultaVeiculos.getListaCliente().isEnabled());

			mensagem = "Entrando em cadastro para edição!";
		}
		else {
			mensagem = "Foi encontrado um erro ao entrar no modo de edicão!";
		}
		return mensagem;
	}

	/**
	 * Método que aciona a atualização do cadastro de um veículo no banco de dados através do codigo na tela
	 * @return mensagem - com o resultado para o usuário
	 */
	public String atualizarVeiculo(){
		String mensagem;

		try {
			int codigo = Integer.parseInt(viewConsultaVeiculos.getTxtCodVeiculo().getText());
			String placa = viewConsultaVeiculos.getTxtPlaca().getText();
			String cor = viewConsultaVeiculos.getTxtCor().getText();
			String modelo = viewConsultaVeiculos.getTxtModelo().getText();
			String marca = viewConsultaVeiculos.getTxtMarca().getText();
			String ativo = (String) viewConsultaVeiculos.getListaAtivo().getSelectedItem();
			int ano = Integer.parseInt(viewConsultaVeiculos.getTxtAno().getText());

			if(placa.length()==0) {
				mensagem = "É obrigatório informar a placa do veículo!"; //Conforme RN12
			}
			else if(cor.length()==0) {
				mensagem = "É obrigatório informar a cor do veículo!"; //Conforme RN12
			}
			else if(modelo.length()==0) {
				mensagem = "É obrigatório informar o modelo do veículo!"; //Conforme RN12
			}
			else if(marca.length()==0) {
				mensagem = "É obrigatório informar a marca do veículo!"; //Conforme RN12
			}
			else if(ano==0) {
				mensagem = "É obrigatório informar o ano do veículo!"; //Conforme RN12
			}
			else {
				//pegando o codigo do cliente
				String clienteSelecionado = (String) viewConsultaVeiculos.getListaCliente().getSelectedItem();
				int posicaoDoCodigo = clienteSelecionado.indexOf("-");
				int codigoCliente = Integer.parseInt(clienteSelecionado.substring(0, posicaoDoCodigo));

				ClientesDAO clienteDAO = new ClientesDAO();
				if(clienteDAO.clienteAtivo(codigoCliente)==true) {
					Clientes cliente = new Clientes(codigoCliente);
					Veiculos veiculo = new Veiculos(codigo,placa,modelo,marca,ano,cor, cliente, ativo);

					VeiculosDAO veiculoDAO = new VeiculosDAO();
					mensagem = veiculoDAO.atualizarVeiculoBanco(veiculo);}
				else {
					mensagem = "Atenção: O cliente está INATIVO, por favor selecione um cliente ATIVO!";
				}
			}
		}
		catch(NumberFormatException erro) {
			mensagem = "Por favor digite um ano valido!";
		}
		return mensagem;
	}
}
