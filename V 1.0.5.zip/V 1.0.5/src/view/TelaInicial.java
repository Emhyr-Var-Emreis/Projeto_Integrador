package view;

public class TelaInicial {
	

	public static void main(String[] args) {
		TelaLogin telaLogin = new TelaLogin();
	}
	
}
