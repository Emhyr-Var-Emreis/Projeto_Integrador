package view.estilos;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JLabel;

public class Titulo extends JLabel{

	private static final long serialVersionUID = 3295946855145957121L;

	/**
	 * Cria uma label para ser usada como titulo com base nos parametros recebidos
	 * @param x - Valor do tipo int para posicionamento do elemento no eixo x
     * @param y - Valor do tipo int para posicionamento do elemento no eixo y
     * @param comprimento - Valor do tipo int para comprimento do elemento
     * @param altura - Valor do tipo int para altura do elemento
	 * @param texto - Texto a ser mostrado no sistema
	 */
	public Titulo(int x, int y, int comprimento, int altura, String texto) {
		super(texto);
        setForeground(new Color(255, 255, 255));
        setBounds(x, y, comprimento, altura);
        setFont(new Font("Tahoma", Font.PLAIN, 60));
	}
}
