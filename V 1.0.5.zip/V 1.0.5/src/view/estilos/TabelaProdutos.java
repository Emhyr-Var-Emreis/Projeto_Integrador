package view.estilos;

import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class TabelaProdutos extends JPanel {

	private static final long serialVersionUID = -802168102070917495L;

	private JTable table;
    private DefaultTableModel model;
    private JButton btnIncluir = new JButton("Incluir");
    private JButton btnApagar = new JButton("Apagar");

    /**
     * Obtém a tabela utilizada na classe.
     *
     * @return a tabela utilizada na classe.
     */
    public JTable getTable() {
        return table;
    }

    /**
     * Define a tabela utilizada na classe.
     *
     * @param table a tabela a ser definida.
     */
    public void setTable(JTable table) {
        this.table = table;
    }

    /**
     * Obtém o botão "Incluir".
     *
     * @return o botão "Incluir".
     */
    public JButton getBtnIncluir() {
        return btnIncluir;
    }

    /**
     * Define o botão "Incluir".
     *
     * @param btnIncluir o botão "Incluir" a ser definido.
     */
    public void setBtnIncluir(JButton btnIncluir) {
        this.btnIncluir = btnIncluir;
    }

    /**
     * Obtém o botão "Apagar".
     *
     * @return o botão "Apagar".
     */
    public JButton getBtnApagar() {
        return btnApagar;
    }

    /**
     * Define o botão "Apagar".
     *
     * @param btnApagar o botão "Apagar" a ser definido.
     */
    public void setBtnApagar(JButton btnApagar) {
        this.btnApagar = btnApagar;
    }

    /**
     * Define o modelo da tabela.
     *
     * @param model o modelo da tabela a ser definido.
     */
    public void setModel(DefaultTableModel model) {
        this.model = model;
    }

    
    public TabelaProdutos() {
        setLayout(new BorderLayout());

        model = new DefaultTableModel(
                new Object[][]{},
                new String[]{"Código", "Nome", "Medida", "Qtd", "Valor Unit", "Valor"}
        ) {
			private static final long serialVersionUID = -792600202308802945L;


			@Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(model);

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(btnIncluir);
        buttonPanel.add(btnApagar);

        add(new JScrollPane(table), BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    /**
     * Obtém o modelo da tabela.
     *
     * @return o modelo da tabela.
     */
    public DefaultTableModel getModel() {
        return model;
    }
}
