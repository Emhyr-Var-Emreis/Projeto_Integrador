package view.estilos;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;

public class CamposTexto extends JTextField {
    
    private static final long serialVersionUID = 2446790998245792842L;

    /**
     * Cria uma caixa de texto, de acordo com a posição, comprimento, altura e quantidade de caracteres informados
     * @param x - Valor do tipo int para posicionamento do elemento no eixo x
     * @param y - Valor do tipo int para posicionamento do elemento no eixo y
     * @param comprimento - Valor do tipo int para comprimento do elemento
     * @param altura - Valor do tipo int para altura do elemento
     * @param maxCaracteres - Valor do tipo int para a quantidade máxima de caracteres permitidos
     */
    public CamposTexto(int x, int y, int comprimento, int altura, int limiteDeCaracteres) {
        setFont(new Font("Tahoma", Font.PLAIN, 24));
        setBounds(x, y, comprimento, altura);
        setBorder(new LineBorder(new Color(0, 0, 0), 2));
        setDocument(new LimiteDeCaracteres(limiteDeCaracteres));
    }
    
    public class LimiteDeCaracteres extends PlainDocument {
        
		private static final long serialVersionUID = 5845922866510243678L;
		private int maxCaracteres;
		
		/**
         * Cria uma instância de LimiteDeCaracteres com a quantidade máxima de caracteres especificada.
         * 
         * @param maxCaracteres - Quantidade máxima de caracteres permitidos
         */
		
        public LimiteDeCaracteres(int maxCaracteres) {
            this.maxCaracteres = maxCaracteres;
        }
        
        /**
         * Insere uma string no documento, respeitando o limite máximo de caracteres.
         * 
         * @param posicaoString - Posicao de insercao da string
         * @param str  - String a ser inserida
         * @param a    - Atributos do texto a ser inserido
         * @throws BadLocationException se ocorrer um erro de posição inválida
         */
        @Override
        public void insertString(int posicaoString, String str, AttributeSet a) throws BadLocationException {
            if (str == null)
                return;
            
            int length = getLength() + str.length();
            
            if (length <= maxCaracteres) {
                super.insertString(posicaoString, str, a);
            }
        }
    }

}
