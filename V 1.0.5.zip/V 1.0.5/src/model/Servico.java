package model;

public class Servico {
	private int codServico;
	private String nome;
	private String descricao;
	private double valor;
	
	
	/**
	 * Constroi um objeto do tipo Servico
	 * @param codServico - codigo do servico do tipo inteiro
	 * @param nome - nome do servico do tipo string
	 * @param descricao - descricao do servico do tipo string
	 * @param valor - valor do servico no tipo double
	 */
	public Servico(int codServico, String nome, String descricao, double valor) {
		this.codServico = codServico;
		this.nome = nome;
		this.descricao = descricao;
		this.valor = valor;
	}
	
	/**
	 * Controi um objeto do tipo servico com base no codigo
	 * @param codServico - codigo do servico do tipo inteiro
	 */
	public Servico(int codServico) {
		this.codServico = codServico;
	}
	
	/**
	 * Constroi um objeto do tipo Servico
	 * @param nome - nome do servico do tipo string
	 * @param descricao - descricao do servico do tipo string
	 * @param valor - valor do servico no tipo double
	 */
	public Servico(String nome, String descricao, double valor) {
		this.nome = nome;
		this.descricao = descricao;
		this.valor = valor;
	}
	public int getCodServico() {
		return codServico;
	}
	public void setCodServico(int codServico) {
		this.codServico = codServico;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	
	


}
