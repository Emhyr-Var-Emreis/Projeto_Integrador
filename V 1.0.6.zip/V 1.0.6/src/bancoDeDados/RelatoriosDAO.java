package bancoDeDados;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.sql.SQLException;

public class RelatoriosDAO {

	private BD bd = new BD();
	private static String caminho = System.getProperty("user.home") + File.separator;

	/**
	 * Salva os dados da tabela servico em "Servicos.csv"
	 * @return String - mensagem retornada ao usuario
	 */
	public String exportarFaturamentoServicoBanco() {
		String mensagem;
		bd.getConnection();
		try {
			PrintWriter pw = new PrintWriter(caminho + "FaturamentoServicos.csv");
			String sql = "select * from item_servico";
			bd.st = bd.con.prepareStatement(sql);
			bd.rs = bd.st.executeQuery();
			while(bd.rs.next()) {
				String linha = 
						bd.rs.getInt(1)+";"+bd.rs.getDouble(2)+";"+bd.rs.getInt(3)+";"+bd.rs.getInt(4);
				System.out.println(linha);
				pw.write(linha+"\n");
			}
			pw.close();

			mensagem = "Salvo com sucesso em " + caminho + "!";
		}
		catch (SQLException e) {
			mensagem = "Não foi possível gerar relatório!";
		}
		catch (FileNotFoundException e) {
			mensagem = "Não foi possível gerar relatório!";

		}
		finally {
			bd.close();
		}
		return mensagem;
	}

	/**
	 * Salva os dados da tabela cliente em "Clientes.csv"
	 * @return String - mensagem retornada ao usuario
	 */
	public String exportarClienteBanco() {
		String mensagem;
		String sql = "select * from cliente";

		bd.getConnection();
		try {
			PrintWriter pw = new PrintWriter(caminho + "Clientes.csv");

			bd.st = bd.con.prepareStatement(sql);
			bd.rs = bd.st.executeQuery();
			while(bd.rs.next()) {
				String linha = bd.rs.getInt(1)+";"+bd.rs.getString(2)+";"+bd.rs.getString(3)+";"+bd.rs.getString(4)+";"+bd.rs.getString(5)+";"+bd.rs.getString(6)+";"+bd.rs.getString(7)+";"+bd.rs.getString(8)+";"+bd.rs.getString(9);
				System.out.println(linha);
				pw.write(linha+"\n");
			}
			pw.close();

			mensagem = "Salvo com sucesso em " + caminho + "!";

		}
		catch (SQLException e) {
			mensagem = "Não foi possível gerar o relatório" + e;
		}
		catch (FileNotFoundException e) {
			mensagem = "Não foi possível gerar o relatório";

		}
		finally {
			bd.close();
		}
		return mensagem;
	}

	/**
	 * Salva os dados da tabela veiculo em "Veiculos.csv"
	 * @return String - mensagem retonrnada ao usuário
	 */
	public String exportarVeiculoBanco() {
		String mensagem;
		bd.getConnection();
		try {
			PrintWriter pw = new PrintWriter(caminho+"Veiculos.csv");
			String sql = "select * from veiculo";
			bd.st = bd.con.prepareStatement(sql);
			bd.rs = bd.st.executeQuery();
			while(bd.rs.next()) {
				String linha = 
						bd.rs.getInt(1)+";"+bd.rs.getString(2)+";"+bd.rs.getString(3)+";"+bd.rs.getString(4)+";"+bd.rs.getString(5)+";"+bd.rs.getInt(6)+";"+bd.rs.getString(7)+";"+bd.rs.getInt(8);
				System.out.println(linha);
				pw.write(linha+"\n");
			}
			pw.close();
			mensagem = "Salvo com sucesso em " + caminho + "!";

		}
		catch (SQLException e) {
			mensagem = "Não foi possível gerar o relatório";
		}
		catch (FileNotFoundException e) {
			mensagem = "Não foi possível gerar o relatório";

		}
		finally {
			bd.close();
		}
		return mensagem;
	}

	/**
	 * Salva os dados da tabela produto em "Produtos.csv"
	 * @return String - mensagem retornada ao usuário
	 */
	public String exportarFaturamentoProdutoBanco() {
		String mensagem;
		bd.getConnection();
		try {
			PrintWriter pw = new PrintWriter(caminho + "FaturamentoProdutos.csv");
			String sql = "select * from item_produto";
			bd.st = bd.con.prepareStatement(sql);
			bd.rs = bd.st.executeQuery();
			while(bd.rs.next()) {
				String linha = 
						bd.rs.getInt(1)+";"+bd.rs.getDouble(2)+";"+bd.rs.getInt(3)+";"+bd.rs.getInt(4);
				System.out.println(linha);
				pw.write(linha+"\n");
			}
			pw.close();
			mensagem = "Salvo com sucesso em " + caminho + "!";

		}
		catch (SQLException e) {
			mensagem = "Não foi possível gerar o relatório";
		}
		catch (FileNotFoundException e) {
			mensagem = "Não foi possível gerar o relatório"+e;

		}
		finally {
			bd.close();
		}
		return mensagem;
	}

	/**
	 * Salva os dados da tabela ordem_servico em "OS.csv"
	 * @return String - mensagem retornada ao usuário
	 */
	public String exportarOSBanco() {
		String mensagem;
		bd.getConnection();
		try {
			PrintWriter pw = new PrintWriter(caminho + "OS.csv");
			String sql = "select * from ordem_servico";
			bd.st = bd.con.prepareStatement(sql);
			bd.rs = bd.st.executeQuery();
			while(bd.rs.next()) {
				String linha = 
						bd.rs.getInt(1)+";"+bd.rs.getString(2)+";"+bd.rs.getString(3)+";"+bd.rs.getString(4)+";"+bd.rs.getDouble(5)+";"+bd.rs.getString(6)+";"+bd.rs.getString(7);
				System.out.println(linha);
				pw.write(linha+"\n");
			}
			pw.close(); 
			mensagem = "Salvo com sucesso em " + caminho + "!";

		}
		catch (SQLException e) {
			mensagem = "Não foi possível gerar o relatório";
		}
		catch (FileNotFoundException e) {
			mensagem = "Não foi possível gerar o relatório";

		}
		finally {
			bd.close();
		}
		return mensagem;
	}

	/**
	 * Salva os dados da tabela funcionario em "Funcionarios.csv"
	 * @return String - mensagem retornada ao usuário
	 */
	public String exportarFuncionarioBanco() {
		String mensagem;
		bd.getConnection();
		try {
			PrintWriter pw = new PrintWriter(caminho + "Funcionarios.csv");
			String sql = "select * from funcionario";
			bd.st = bd.con.prepareStatement(sql);
			bd.rs = bd.st.executeQuery();
			while(bd.rs.next()) {
				String linha = 
						bd.rs.getInt(1)+";"+bd.rs.getString(2)+";"+bd.rs.getString(3)+";"+bd.rs.getString(4)+";"+bd.rs.getString(5)+";"+bd.rs.getString(6)+";"+bd.rs.getString(7)+";"+bd.rs.getString(8)+";"+bd.rs.getString(9)+";"+bd.rs.getString(10)+";"+bd.rs.getString(11);
				System.out.println(linha);
				pw.write(linha+"\n");
			}
			pw.close();
			mensagem = "Salvo com sucesso em " + caminho + "!";

		}
		catch (SQLException e) {
			mensagem = "Não foi possível gerar o relatório";
		}
		catch (FileNotFoundException e) {
			mensagem = "Não foi possível gerar o relatório";

		}
		finally {
			bd.close();
		}
		return mensagem;
	}
	
	/**
	 * Salva os dados da tabela produto em "Produtos.csv"
	 * @return String - mensagem retornada ao usuário
	 */
	public String exportarProdutoBanco() {
		String mensagem;
		bd.getConnection();
		try {
			PrintWriter pw = new PrintWriter(caminho + "Produtos.csv");
			String sql = "select * from produto";
			bd.st = bd.con.prepareStatement(sql);
			bd.rs = bd.st.executeQuery();
			while(bd.rs.next()) {
				String linha = 
						bd.rs.getInt(1)+";"+bd.rs.getString(2)+";"+bd.rs.getString(3)+";"+bd.rs.getDouble(4)+";"+bd.rs.getString(5);
				System.out.println(linha);
				pw.write(linha+"\n");
			}
			pw.close();
			mensagem = "Salvo com sucesso em " + caminho + "!";

		}
		catch (SQLException e) {
			mensagem = "Não foi possível gerar o relatório";
		}
		catch (FileNotFoundException e) {
			mensagem = "Não foi possível gerar o relatório";

		}
		finally {
			bd.close();
		}
		return mensagem;
	}

}
