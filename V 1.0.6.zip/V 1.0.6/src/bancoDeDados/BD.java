package bancoDeDados;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class BD {

	public Connection con; // conexao
	public PreparedStatement st; // execucao instrucao sql
	public ResultSet rs; // recebe o resultado da instrucao sql

	//credenciais de acesso (arquivo externo)

	private final String DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	private final String DATABASENAME = "bd9";
	private final String URL = "jdbc:sqlserver://localhost:1433;databasename="+DATABASENAME;
	private final String LOGIN = "sa";
	private final String SENHA = "123456";
	
	/**
	 * Metodo para fazer a conexão com o banco de dados
	 * @return - um resultado boolean conforme conexão
	 */
	public boolean getConnection() {
		try {
			Class.forName(DRIVER); //não seja encontrado 
			con = DriverManager.getConnection(URL, LOGIN, SENHA);
			return true;
		}
		catch(ClassNotFoundException erro) {
			
			JOptionPane.showMessageDialog(null,"Driver não encontrado!" );

		}
		catch(SQLException erro) {
			JOptionPane.showMessageDialog(null,"Driver não encontrado!" + erro );

		}
		return false;

	}

	public void close() {
		try {
			if(rs!=null) rs.close();
		}
		catch(SQLException erro) {}
		try {
			if(st!=null) st.close();
		}
		catch(SQLException erro) {}
		try {
			if(con!=null) {
				con.close();
			};
		}
		catch(SQLException erro) {}
	}


}



