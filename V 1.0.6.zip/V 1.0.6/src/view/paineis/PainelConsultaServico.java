package view.paineis;


import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.JPanel;


import controller.ConsultarServicoController;
import view.estilos.BotaoEditar;

import view.estilos.BotaoPesquisar;
import view.estilos.BotaoSalvar;
import view.estilos.CamposTexto;
import view.estilos.LabelsTexto;
import view.estilos.Titulo;


public class PainelConsultaServico extends JPanel {

	private static final long serialVersionUID = 419540971453719896L;

	private final ConsultarServicoController controller;

	private Titulo lblTituloServico;
	private LabelsTexto lblCodServico;
	private LabelsTexto lblNome;
	private LabelsTexto lblDescricao;
	private LabelsTexto lblValor;
	private CamposTexto txtCodServico;
	private CamposTexto txtNome;
	private CamposTexto txtDescricao;
	private CamposTexto txtValor;
	private BotaoSalvar btnSalvar;
	private BotaoPesquisar btnPesquisar;
	private BotaoEditar btnEditar;

	
	public Titulo getLblTituloServico() {
		return lblTituloServico;
	}

	public void setLblTituloServico(Titulo lblTituloServico) {
		this.lblTituloServico = lblTituloServico;
	}

	public BotaoPesquisar getBtnPesquisar() {
		return btnPesquisar;
	}

	public void setBtnPesquisar(BotaoPesquisar btnPesquisar) {
		this.btnPesquisar = btnPesquisar;
	}

	public BotaoEditar getBtnEditar() {
		return btnEditar;
	}

	public void setBtnEditar(BotaoEditar btnEditar) {
		this.btnEditar = btnEditar;
	}

	public Titulo getlblTituloServico() {
		return lblTituloServico;
	}

	public void setlblTituloServico(Titulo lblTituloServico) {
		this.lblTituloServico = lblTituloServico;
	}

	public LabelsTexto getLblCodServico() {
		return lblCodServico;
	}

	public void setLblCodServico(LabelsTexto lblCodServico) {
		this.lblCodServico = lblCodServico;
	}

	public LabelsTexto getLblNome() {
		return lblNome;
	}

	public void setLblNome(LabelsTexto lblNome) {
		this.lblNome = lblNome;
	}

	public LabelsTexto getLblDescricao() {
		return lblDescricao;
	}

	public void setLblDescricao(LabelsTexto lblDescricao) {
		this.lblDescricao = lblDescricao;
	}

	public LabelsTexto getLblValor() {
		return lblValor;
	}

	public void setLblValor(LabelsTexto lblValor) {
		this.lblValor = lblValor;
	}

	public CamposTexto getTxtCodServico() {
		return txtCodServico;
	}

	public void setTxtCodServico(CamposTexto txtCodServico) {
		this.txtCodServico = txtCodServico;
	}

	public CamposTexto getTxtNome() {
		return txtNome;
	}

	public void setTxtNome(CamposTexto txtNome) {
		this.txtNome = txtNome;
	}

	public CamposTexto getTxtDescricao() {
		return txtDescricao;
	}

	public void setTxtDescricao(CamposTexto txtDescricao) {
		this.txtDescricao = txtDescricao;
	}

	public CamposTexto getTxtValor() {
		return txtValor;
	}

	public void setTxtValor(CamposTexto txtValor) {
		this.txtValor = txtValor;
	}

	public BotaoSalvar getBtnSalvar() {
		return btnSalvar;
	}

	public void setBtnSalvar(BotaoSalvar btnSalvar) {
		this.btnSalvar = btnSalvar;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public ConsultarServicoController getController() {
		return controller;
	}

	public PainelConsultaServico() {

		controller = new ConsultarServicoController(this);

		setSize(1040,768);
		setBackground(new Color(109, 110, 114));
		setLayout(null);

		//Criando texto na tela 

		lblTituloServico = new Titulo(261,32,602,60,"Consulta de Serviços");
		lblCodServico = new LabelsTexto(101,121,126,29,"Cód Serviço");
		lblNome = new LabelsTexto(158,177,69,29,"Nome");
		lblDescricao = new LabelsTexto(105,230,117,29,"Descrição");
	    lblValor = new LabelsTexto(460,283,209,29,"Valor Mão de Obra");



		//Criando inputs texto na tela
		txtCodServico = new CamposTexto(260,124,81,29,20);
		txtNome = new CamposTexto(260,177,650,29,70);
		txtNome.setEditable(false);
		txtDescricao = new CamposTexto(260,230,650,29,150);
		txtDescricao.setEditable(false);
		txtValor = new CamposTexto(715,283,195,29,20);
		txtValor.setEditable(false);


		//Criando botoes da tela
		btnSalvar = new BotaoSalvar("Salvar");
		btnPesquisar = new BotaoPesquisar("Pesquisar");
		btnEditar = new BotaoEditar("Editar");

		//Adicionando elementos a tela
		add(lblTituloServico);
		add(lblCodServico);
		add(lblNome);
		add(lblDescricao);
		add(lblValor);
		add(txtCodServico);
		add(txtNome);
		add(txtDescricao);
		add(txtValor);
		add(btnSalvar);
		add(btnPesquisar);
		add(btnEditar);
		btnSalvar.setVisible(false);
		
		/**
		 * Aciona o metodo de pesquisa do servico
		 */
		btnPesquisar.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				JOptionPane.showMessageDialog(null, controller.pesquisarServico());
			}
		});

		/**
		 * Aciona o modo de edicao do servico
		 */
		btnEditar.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				JOptionPane.showMessageDialog(null, controller.liberarEdicao());
			}
		});
		
		/**
		 * Aciona o metodo para salvar o servico
		 */
		btnSalvar.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				JOptionPane.showMessageDialog(null, controller.atualizarServico());

			}
		});


	}}
