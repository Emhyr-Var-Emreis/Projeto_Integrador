package view.paineis;


import java.awt.Color;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JPanel;


import view.estilos.BotaoMenu;
import view.estilos.Subtitulo;
import view.estilos.Titulo;

public class PainelProdutos extends JPanel{

	private static final long serialVersionUID = 5087889307920279769L;

	public PainelProdutos() {
		setBackground(new Color(109, 110, 114)); // Define a cor de fundo do painel em RGB
		setSize(1040,768);
		setLayout(null);
		//Criando texto na tela  
		Titulo lblProdutos = new Titulo(413, 32, 235, 84,"Produtos");

		Subtitulo lblOperacao = new Subtitulo(138, 148, 732, 44,"Por favor selecione a operação que deseja realizar:");

		//Criando botões de operações nas tela 
		BotaoMenu btnCadastrarProdutos = new BotaoMenu("Cadastrar Produtos", 252, 225, 538, 73);
		btnCadastrarProdutos.setIcon(new ImageIcon(PainelProdutos.class.getResource("/view/img/cadastrar.png")));
		BotaoMenu btnConsultarProdutos = new BotaoMenu("Consultar Produtos", 252, 330, 538, 73);
		btnConsultarProdutos.setIcon(new ImageIcon(PainelProdutos.class.getResource("/view/img/consultar.png")));
		BotaoMenu btnEditarProdutos = new BotaoMenu("Editar Produtos", 252, 435, 538, 73);
		btnEditarProdutos.setIcon(new ImageIcon(PainelProdutos.class.getResource("/view/img/editarMenu.png")));

		//Adicionando elementos a tela
		add(btnCadastrarProdutos);
		add(btnConsultarProdutos);
		add(btnEditarProdutos);
		add(lblProdutos);
		add(lblOperacao);
		
		/**
		 * Redireciona para a tela de Cadastro de produtos
		 */
		btnCadastrarProdutos.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				removeAll();
				PainelCadastrarProdutos painelCadastrarProdutos = new PainelCadastrarProdutos();
				add(painelCadastrarProdutos);
				revalidate();
				repaint();
				

			}
		});
		
		/**
		 * Redireciona para a tela de consulta de produtos
		 */
		btnConsultarProdutos.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				removeAll();
				PainelConsultarProdutos painelConsultarProdutos = new PainelConsultarProdutos();
				add(painelConsultarProdutos);
				revalidate();
				repaint();
				

			}
		});
		
		/**
		 * Redireciona para a tela de Edicao do Produtos
		 */
		btnEditarProdutos.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				removeAll();
				PainelConsultarProdutos painelEditarProdutos = new PainelConsultarProdutos();
				add(painelEditarProdutos);
				painelEditarProdutos.getBtnPesquisar().setVisible(false);
				painelEditarProdutos.getlblTituloProdutos().setText("Editar Produtos");
				revalidate();
				repaint();
				

			}
		});
	}
}
