package view.paineis;


import java.awt.Color;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JPanel;


import view.estilos.BotaoMenu;
import view.estilos.Subtitulo;
import view.estilos.Titulo;

public class PainelVeiculos extends JPanel{

	private static final long serialVersionUID = 7874399326824171809L;

	public PainelVeiculos() {
		setBackground(new Color(109, 110, 114)); // Define a cor de fundo do painel em RGB
		setSize(1040,768);
		setLayout(null);
		//Criando texto na tela  
		Titulo lblVeiculos = new Titulo(413, 32, 235, 84,"Veículos");

		Subtitulo lblOperacao = new Subtitulo(138, 148, 732, 44,"Por favor selecione a operação que deseja realizar:");

		//Criando botões de operações nas tela 
		BotaoMenu btnCadastrarVeiculo = new BotaoMenu("Cadastrar Veículos", 252, 225, 538, 73);
		btnCadastrarVeiculo.setIcon(new ImageIcon(PainelVeiculos.class.getResource("/view/img/cadastrar.png")));
		BotaoMenu btnConsultarVeiculo = new BotaoMenu("Consultar Veículos", 252, 330, 538, 73);
		btnConsultarVeiculo.setIcon(new ImageIcon(PainelVeiculos.class.getResource("/view/img/consultar.png")));
		BotaoMenu btnEditarVeiculos = new BotaoMenu("Editar Veiculos", 252, 435, 538, 73);
		btnEditarVeiculos.setIcon(new ImageIcon(PainelVeiculos.class.getResource("/view/img/editarMenu.png")));

		//Adicionando elementos a tela
		add(btnCadastrarVeiculo);
		add(btnConsultarVeiculo);
		add(btnEditarVeiculos);
		add(lblVeiculos);
		add(lblOperacao);
		
		/**
		 * Redireciona para a tela de cadastro de Veiculos
		 */
		btnCadastrarVeiculo.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				removeAll();
				PainelCadastrarVeiculos painelCadastrarVeiculo = new PainelCadastrarVeiculos();
				add(painelCadastrarVeiculo);
				revalidate();
				repaint();
				

			}
		});
		
		/**
		 * Redireciona para a tela de Consulta de Veiculos
		 */
		btnConsultarVeiculo.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				removeAll();
				PainelConsultarVeiculos painelConsultaVeiculo = new PainelConsultarVeiculos();
				add(painelConsultaVeiculo);
				revalidate();
				repaint();
				

			}
		});
		
		/**
		 * Redireciona para a tela de Edicao do Veiculos
		 */
		btnEditarVeiculos.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				removeAll();
				PainelConsultarVeiculos painelEditarVeiculos = new PainelConsultarVeiculos();
				add(painelEditarVeiculos);
				painelEditarVeiculos.getBtnPesquisar().setVisible(false);
				painelEditarVeiculos.getlblTituloVeiculos().setText("Editar Veículos");
				revalidate();
				repaint();
				

			}
		});
	}
}