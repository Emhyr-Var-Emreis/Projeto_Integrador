package model;

public class Funcionarios {
	private int matricula;
	private String nome;
	private String docFuncionario;
	private String telefone;
	private String endereco;
	private String email;
	private String cidade;
	private String cargo;
	private String usuario;
	private String senha;

	/**
	 * Constroi um objeto do tipo Funcionarios com base no usuario e senha
	 * @param usuario - login do tipo string do funcionario no sistema
	 * @param senha - senha do tipo string de acesso para o sistema
	 */
	public Funcionarios(String usuario, String senha) {
		this.usuario = usuario;
		this.senha = senha;
	}

	/**
	 * Constroi um objeto do tipo Funcionarios
	 * @param matricula - matricula do tipo int do funcionario
	 * @param nome - nome do tipo string do funcionario
	 * @param docFuncionario - documento do tipo string do funcionario
	 * @param telefone - telefone do tipo string do funcionario
	 * @param endereco - endereco do tipo string do funcionario
	 * @param email - email do tipo string do funcionario
	 * @param ativo -valor do tipo string sim ou não para verificar se o funcionario esta ativo
	 * @param cidade - cidade do tipo string do funcionario
	 * @param cargo - cargo do tipo string do funcionario
	 * @param usuario - login do tipo string do funcionario no sistema
	 * @param senha - senha do tipo string de acesso para o sistema
	 */
	public Funcionarios(int matricula, String nome, String docFuncionario, String telefone, String endereco,
			String email, String ativo, String cidade, String cargo, String usuario, String senha) {
		this.matricula = matricula;
		this.nome = nome;
		this.docFuncionario = docFuncionario;
		this.telefone = telefone;
		this.endereco = endereco;
		this.email = email;
		this.ativo = ativo;
		this.cidade = cidade;
		this.cargo = cargo;
		this.usuario = usuario;
		this.senha = senha;
	}
	private String ativo;

	/**
	 * Controi o obejto do tipo funcionario com base na matricula
	 * @param matricula - valor inteiro da matricula do funcionario
	 */
	public Funcionarios(int matricula) {
		this.matricula = matricula;
	}

	/**
	 * Constroi um objeto do tipo Funcionarios
	 * @param nome - nome do tipo string do funcionario
	 * @param docFuncionario - documento do tipo string do funcionario
	 * @param telefone - telefone do tipo string do funcionario
	 * @param endereco - endereco do tipo string do funcionario
	 * @param email - email do tipo string do funcionario
	 * @param cidade - cidade do tipo string do funcionario
	 * @param cargo - cargo do tipo string do funcionario
	 * @param usuario - login do tipo string do funcionario no sistema
	 * @param senha - senha do tipo string de acesso para o sistema
	 */
	public Funcionarios(String nome, String docFuncionario, String telefone, String endereco, String email,
			String cidade, String cargo, String usuario, String senha) {

		this.nome = nome;
		this.docFuncionario = docFuncionario;
		this.telefone = telefone;
		this.endereco = endereco;
		this.email = email;
		this.cidade = cidade;
		this.cargo = cargo;
		this.usuario = usuario;
		this.senha = senha;
	}

	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}


	public int getMatricula() {
		return matricula;
	}
	public void setMatricula(int matricula) {
		this.matricula = matricula;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getDocFuncionario() {
		return docFuncionario;
	}
	public void setDocFuncionario(String docFuncionario) {
		this.docFuncionario = docFuncionario;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public String getCidade() {
		return cidade;
	}
	public void setCidade(String cidade) {
		this.cidade = cidade;
	}
	public String getCargo() {
		return cargo;
	}
	public void setCargo(String cargo) {
		this.cargo = cargo;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	public String getAtivo() {
		return ativo;
	}

	public void setAtivo(String ativo) {
		this.ativo = ativo;
	}
}
