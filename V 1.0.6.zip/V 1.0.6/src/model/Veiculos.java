package model;


public class Veiculos {
	private int codigoVeiculo;
	private String placa;
	private String modelo;
	private String marca;
	private int ano;
	private String cor;
	private Clientes cliente;
	private String ativo;
	
	
	/**
	 * Constroi um objeto do tipo Veiculo
	 * @param codigoVeiculo - codigo do veículo no tipo inteiro
	 * @param placa - placa do veiculo do tipo string
	 * @param modelo - modelo do veiculo do tipo string
	 * @param marca - marca do veiculo do tipo string
	 * @param ano - ano do veiculo no tipo inteiro
	 * @param cor - cor do veiculo no tipo string
	 * @param cliente - cliente do tipo Clientes associado ao veiculo
	 * @param ativo - valor do tipo string sim ou não para verificar se o veiculo esta ativo
	 */
	public Veiculos(int codigoVeiculo, String placa, String modelo, String marca, int ano, String cor, Clientes cliente,
			String ativo) {
		
		this.codigoVeiculo = codigoVeiculo;
		this.placa = placa;
		this.modelo = modelo;
		this.marca = marca;
		this.ano = ano;
		this.cor = cor;
		this.cliente = cliente;
		this.ativo = ativo;
	}
	
	/**
	 * Constroi um objeto do tipo Veiculo com base no código
	 * @param codigoVeiculo - codigo do veículo no valor inteiro
	 */
	public Veiculos(int codigoVeiculo) {
		this.codigoVeiculo = codigoVeiculo;
	}
	
	/**
	 * Constroi um objeto do tipo Veiculo
	 * @param placa - placa do veiculo do tipo string
	 * @param modelo - modelo do veiculo do tipo string
	 * @param marca - marca do veiculo do tipo string
	 * @param ano - ano do veiculo no tipo inteiro
	 * @param cor - cor do veiculo no tipo string
	 * @param cliente - cliente do tipo Clientes associado ao veiculo
	 */
	public Veiculos(String placa, String modelo, String marca, int ano, String cor, Clientes cliente) {
		this.placa = placa;
		this.modelo = modelo;
		this.marca = marca;
		this.ano = ano;
		this.cor = cor;
		this.cliente = cliente;
	}
	public int getCodigoVeiculo() {
		return codigoVeiculo;
	}
	public void setCodigoVeiculo(int codigoVeiculo) {
		this.codigoVeiculo = codigoVeiculo;
	}
	public String getPlaca() {
		return placa;
	}
	public void setPlaca(String placa) {
		this.placa = placa;
	}
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public int getAno() {
		return ano;
	}
	public void setAno(int ano) {
		this.ano = ano;
	}
	public String getCor() {
		return cor;
	}
	public void setCor(String cor) {
		this.cor = cor;
	}
	public Clientes getCliente() {
		return cliente;
	}
	public void setCliente(Clientes cliente) {
		this.cliente = cliente;
	}
	public String getAtivo() {
		return ativo;
	}
	public void setAtivo(String ativo) {
		this.ativo = ativo;
	}
	
	
}

