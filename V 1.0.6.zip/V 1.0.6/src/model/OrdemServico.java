package model;

import java.time.LocalDate;
import java.util.List;

public class OrdemServico {
	private int codServico;
	private String status;
	private LocalDate dataExecucao;
	private Veiculos veiculo;
	private Funcionarios funcionario;
	private double valorTotal;
	private List<ItemProduto> produtos;
	private List<ItemServico> servico;
	private LocalDate dataCriacao;
	
	
	

	/**
	 * Controi um objeto do tipo OrdemServico com base no codigo
	 * @param codServico - codigo de valor no tipo inteiro da ordem de servico
	 */
	public OrdemServico(int codServico) {
		this.codServico = codServico;
	}

	/**
	 * Controi um objeto do tipo OrdemServico
	 * @param status - status do tipo string da Ordem de servico
	 * @param dataExecucao - data de execucao da Ordem de Servico do tipo LocalDate
	 * @param veiculo - veiculo da Ordem de Servico do tipo Veiculos
	 * @param funcionario - funcionario associado a Ordem de Servico do tipo Funcionarios
	 * @param valorTotal - valor total da Ordem de Servico do tipo double
	 * @param produtos - lista de produtos da ordem de servico do tipo ItemProduto
	 * @param servico - lista de servicos da ordem de servico do tipo ItemServico
	 */
	public OrdemServico(String status, LocalDate dataExecucao, Veiculos veiculo, Funcionarios funcionario,
			double valorTotal, List<ItemProduto> produtos, List<ItemServico> servico) {
		this.status = status;
		this.dataExecucao = dataExecucao;
		this.veiculo = veiculo;
		this.funcionario = funcionario;
		this.valorTotal = valorTotal;
		this.produtos = produtos;
		this.servico = servico;
	}
	
	/**
	 * Controi um objeto do tipo OrdemServico
	 * @param codServico - codigo do tipo inteiro da Ordem de servico
	 * @param status - status do tipo string da Ordem de servico
	 * @param dataExecucao - data de execucao da Ordem de Servico do tipo LocalDate
	 * @param veiculo - veiculo da Ordem de Servico do tipo Veiculos
	 * @param funcionario - funcionario associado a Ordem de Servico do tipo Funcionarios
	 * @param valorTotal - valor total da Ordem de Servico do tipo double
	 * @param produtos - lista de produtos da ordem de servico do tipo ItemProduto
	 * @param servico - lista de servicos da ordem de servico do tipo ItemServico
	 */
	public OrdemServico(int codServico, String status, LocalDate dataExecucao, Veiculos veiculo, Funcionarios funcionario,
			double valorTotal, List<ItemProduto> produtos, List<ItemServico> servico) {
		this.codServico = codServico;
		this.status = status;
		this.dataExecucao = dataExecucao;
		this.veiculo = veiculo;
		this.funcionario = funcionario;
		this.valorTotal = valorTotal;
		this.produtos = produtos;
		this.servico = servico;
	}
	
	
	public Veiculos getVeiculo() {
		return veiculo;
	}
	public void setVeiculo(Veiculos veiculo) {
		this.veiculo = veiculo;
	}
	public int getCodServico() {
		return codServico;
	}
	public void setCodServico(int codServico) {
		this.codServico = codServico;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public LocalDate getDataExecucao() {
		return dataExecucao;
	}
	public void setDataExecucao(LocalDate dataExecucao) {
		this.dataExecucao = dataExecucao;
	}
	public Funcionarios getFuncionario() {
		return funcionario;
	}
	public void setFuncionario(Funcionarios funcionario) {
		this.funcionario = funcionario;
	}
	public double getValorTotal() {
		return valorTotal;
	}
	public void setValorTotal(double valorTotal) {
		this.valorTotal = valorTotal;
	}

	
	public List<ItemProduto> getProdutos() {
		return produtos;
	}
	public void setProdutos(List<ItemProduto> produtos) {
		this.produtos = produtos;
	}
	public List<ItemServico> getServico() {
		return servico;
	}
	public void setServico(List<ItemServico> servico) {
		this.servico = servico;
	}
	public LocalDate getDataCriacao() {
		return dataCriacao;
	}
	public void setDataCriacao(LocalDate dataCriacao) {
		this.dataCriacao = dataCriacao;
	}
	
	
}
