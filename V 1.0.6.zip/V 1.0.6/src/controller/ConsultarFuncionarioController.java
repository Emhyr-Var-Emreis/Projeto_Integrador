package controller;

import bancoDeDados.FuncionarioDAO;
import model.Funcionarios;
import view.paineis.PainelConsultarFuncionarios;

public class ConsultarFuncionarioController {

	private final PainelConsultarFuncionarios viewConsultaFuncionarios;
	/**
	 * Construtor de comunicacao com o PainelConsultarFuncionarios (view)
	 * @param viewConsultarFuncionario - variavel do tipo PainelConsultarFuncionarios para controle da tela
	 */
	public ConsultarFuncionarioController(PainelConsultarFuncionarios viewConsultaFuncionarios) {
		this.viewConsultaFuncionarios = viewConsultaFuncionarios;
	}

	/**
	 * Metodo que aciona que busca a partir do codigo os dados do funcionario no banco de dados
	 * @return mensagem - com o resultado para o usuário
	 */
	public String pesquisarFuncionario() {

		String mensagem;

		try {
			int matricula = Integer.parseInt(viewConsultaFuncionarios.getTxtMatricula().getText());

			Funcionarios funcionario = new Funcionarios(matricula);

			FuncionarioDAO funcionarioDAO = new FuncionarioDAO();

			funcionarioDAO.pesquisarFuncionarioBanco(funcionario);

			if(funcionarioDAO.pesquisarFuncionarioBanco(funcionario)!=null) {
				viewConsultaFuncionarios.getTxtMatricula().setText(Integer.toString(funcionario.getMatricula()));
				viewConsultaFuncionarios.getTxtNome().setText(funcionario.getNome());
				viewConsultaFuncionarios.getTxtCpf().setText(funcionario.getDocFuncionario());
				viewConsultaFuncionarios.getTxtEmail().setText(funcionario.getEmail());
				viewConsultaFuncionarios.getTxtTelefone().setText(funcionario.getTelefone());
				viewConsultaFuncionarios.getTxtEndereco().setText(funcionario.getEndereco());
				viewConsultaFuncionarios.getTxtCidade().setText(funcionario.getCidade());
				viewConsultaFuncionarios.getTxtCargo().setText(funcionario.getCargo());
				viewConsultaFuncionarios.getTxtLogin().setText(funcionario.getUsuario());
				viewConsultaFuncionarios.getTxtSenha().setText(funcionario.getSenha());
				viewConsultaFuncionarios.getListaAtivo().setSelectedItem(funcionario.getAtivo());
				mensagem = "Funcionário Encontrado!";
			}
			else {
				mensagem = "Ocorreu um erro ao buscar o funcionário!";
			}
		}
		catch(NumberFormatException erro) {
			mensagem = "Por favor digite um código válido!";
		}
		return mensagem;
	}

	/**
	 * Metodo para alterar os estados dos campos da tela e buscar um funcionario através do código para ser editado
	 * @return mensagem - com o resultado para o usuário
	 */
	public String liberarEdicao() {
		String mensagem;
		String teste = pesquisarFuncionario();
		if(teste.equals("Funcionário Encontrado!")) {
			viewConsultaFuncionarios.getBtnSalvar().setVisible(!viewConsultaFuncionarios.getBtnSalvar().isVisible());
			viewConsultaFuncionarios.getTxtMatricula().setEditable(!viewConsultaFuncionarios.getTxtMatricula().isEditable());
			viewConsultaFuncionarios.getTxtNome().setEditable(!viewConsultaFuncionarios.getTxtNome().isEditable());
			viewConsultaFuncionarios.getTxtCpf().setEditable(!viewConsultaFuncionarios.getTxtCpf().isEditable());
			viewConsultaFuncionarios.getTxtEmail().setEditable(!viewConsultaFuncionarios.getTxtEmail().isEditable());
			viewConsultaFuncionarios.getTxtTelefone().setEditable(!viewConsultaFuncionarios.getTxtTelefone().isEditable());
			viewConsultaFuncionarios.getTxtEndereco().setEditable(!viewConsultaFuncionarios.getTxtEndereco().isEditable());
			viewConsultaFuncionarios.getTxtCidade().setEditable(!viewConsultaFuncionarios.getTxtCidade().isEditable());
			viewConsultaFuncionarios.getTxtCargo().setEditable(!viewConsultaFuncionarios.getTxtCargo().isEditable());
			viewConsultaFuncionarios.getTxtLogin().setEditable(!viewConsultaFuncionarios.getTxtLogin().isEditable());
			viewConsultaFuncionarios.getTxtSenha().setEditable(!viewConsultaFuncionarios.getTxtSenha().isEditable());
			viewConsultaFuncionarios.getListaAtivo().setEnabled(!viewConsultaFuncionarios.getListaAtivo().isEnabled());

			mensagem = "Entrando em cadastro para edição!!";

		}
		else {
			mensagem = "Foi encontrado um erro ao entrar no modo de edicão!";
		}
		return mensagem;
	}

	public String atualizarFuncionario(){
		String mensagem;

		int matricula = Integer.parseInt(viewConsultaFuncionarios.getTxtMatricula().getText());

		String nome = viewConsultaFuncionarios.getTxtNome().getText();
		String documento = viewConsultaFuncionarios.getTxtCpf().getText();
		String email = viewConsultaFuncionarios.getTxtEmail().getText();
		String telefone = viewConsultaFuncionarios.getTxtTelefone().getText();
		String endereco = viewConsultaFuncionarios.getTxtEndereco().getText();
		String cidade = viewConsultaFuncionarios.getTxtCidade().getText();
		String cargo = viewConsultaFuncionarios.getTxtCargo().getText();
		String login = viewConsultaFuncionarios.getTxtLogin().getText();
		String senha = viewConsultaFuncionarios.getTxtSenha().getText();
		String ativo = (String)viewConsultaFuncionarios.getListaAtivo().getSelectedItem();

		if(documento.length()>11||documento.length()<11) {
			mensagem = "O CPF deve conter 11 digitos!"; //Conforme RN05 e RN12
		}

		else if(senha.length()<8) {
			mensagem = "A senha deve conter pelo menos 8 digítos!"; //Conforme RN08 e RN12 
		}
		else if(login.length()<=0) {
			mensagem = "É obrigatório informar um login!"; //Conforme RN12
		}
		else if(nome.length()<=0) {
			mensagem = "É obrigatório informar o nome do funcionário!"; //Conforme RN12
		}
		else if(email.length()<=0) {
			mensagem = "É obrigatório informar o email do funcionário!"; //Conforme RN12
		}
		else if(telefone.length()<=0) {
			mensagem = "É obrigatório informar o telefone do funcionário!"; //Conforme RN12
		}
		else if(endereco.length()<=0) {
			mensagem = "É obrigatório informar o endereco do funcionário!"; //Conforme RN12
		}
		else if(cidade.length()<=0) {
			mensagem = "É obrigatório informar a cidade do funcionário!"; //Conforme RN12
		}
		else if(cargo.length()<=0) {
			mensagem = "É obrigatório informar um cargo para o funcionário"; //Conforme RN12
		}
		else {
			Funcionarios funcionario = new Funcionarios(matricula,nome, documento, telefone, endereco, email, ativo, cidade, cargo, login, senha);

			FuncionarioDAO funcionarioDAO = new FuncionarioDAO();

			mensagem = funcionarioDAO.atualizarFuncionarioBanco(funcionario);

		}
		return mensagem;
	}
}

