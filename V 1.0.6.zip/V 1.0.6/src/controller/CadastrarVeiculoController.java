package controller;

import bancoDeDados.ClientesDAO;
import bancoDeDados.VeiculosDAO;
import model.Clientes;
import model.Veiculos;
import view.paineis.PainelCadastrarVeiculos;

public class CadastrarVeiculoController {
	private final PainelCadastrarVeiculos viewCadastroVeiculos;

	/**
	 * Construtor de comunicacao com o PainelCadastroVeiculos (view)
	 * @param viewCadastroVeiculos - variavel do tipo PainelCadastroVeiculos para controle da tela
	 */
	public CadastrarVeiculoController(PainelCadastrarVeiculos viewCadastroVeiculos){
		this.viewCadastroVeiculos = viewCadastroVeiculos;
	}

	/**
	 * Metodo que aciona uma busca no banco de dados por todos os clientes cadastrados
	 * @return listaClientes - retorna um array com todos os veiculos encontrados
	 */
	public String[] listarClientes() {
		ClientesDAO clienteDAO = new ClientesDAO();
		String[] listaClientesAtivos = clienteDAO.listarClientes();
		return listaClientesAtivos;
	}

	/**
	 * Metodo que busca os valores digitados na tela de cadastro de veiculos e aciona o metodo para salvar o veiculo no banco de dados
	 * @return mensagem - - retorna mensagem do tipo String para o usuário
	 */
	public String salvarVeiculo(){
		String mensagem;
		try {
			String placa = viewCadastroVeiculos.getTxtPlaca().getText();
			String cor = viewCadastroVeiculos.getTxtCor().getText();
			String modelo = viewCadastroVeiculos.getTxtModelo().getText();
			String marca = viewCadastroVeiculos.getTxtMarca().getText();
			int ano = Integer.parseInt(viewCadastroVeiculos.getTxtAno().getText());
			if(placa.length()==0) {
				mensagem = "É obrigatório informar a placa do veículo!"; //Conforme RN12
			}
			else if(cor.length()==0) {
				mensagem = "É obrigatório informar a cor do veículo!"; //Conforme RN12
			}
			else if(modelo.length()==0) {
				mensagem = "É obrigatório informar o modelo do veículo!"; //Conforme RN12
			}
			else if(marca.length()==0) {
				mensagem = "É obrigatório informar a marca do veículo!"; //Conforme RN12
			}
			else if(ano==0) {
				mensagem = "É obrigatório informar o ano do veículo!"; //Conforme RN12
			}
			else {
				//pegando o codigo do cliente
				String clienteSelecionado = (String) viewCadastroVeiculos.getListaCliente().getSelectedItem();
				int posicaoDoCodigo = clienteSelecionado.indexOf("-");
				int codigoCliente = Integer.parseInt(clienteSelecionado.substring(0, posicaoDoCodigo));

				ClientesDAO clienteDAO = new ClientesDAO();
				if(clienteDAO.clienteAtivo(codigoCliente)==true) {
					Clientes cliente = new Clientes(codigoCliente);
					Veiculos veiculo = new Veiculos(placa, modelo, marca, ano, cor, cliente);

					VeiculosDAO veiculoDAO = new VeiculosDAO();
					mensagem = veiculoDAO.salvarVeiculo(veiculo);}
				else {
					mensagem = "Atenção: O cliente está INATIVO, por favor selecione um cliente ATIVO!"; //Conforme RN10
				}
			}
		}
		catch(NumberFormatException erro) {
			mensagem = "Por favor digite um ano valido!";
		}
		return mensagem;
	}

	/**
	 * Método para limpar os dados na tela
	 */
	public void limpar() {
		viewCadastroVeiculos.getTxtPlaca().setText("");
		viewCadastroVeiculos.getTxtCor().setText("");
		viewCadastroVeiculos.getTxtModelo().setText("");
		viewCadastroVeiculos.getTxtMarca().setText("");
		viewCadastroVeiculos.getTxtAno().setText("");
	}
}
