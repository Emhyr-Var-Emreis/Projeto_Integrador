package controller;

import bancoDeDados.FuncionarioDAO;
import model.Funcionarios;
import view.TelaInicial;
import view.TelaLogin;
import view.TelaPrincipal;

public class LoginController {
	
	private final TelaLogin viewLogin;
	
	/**
	 * Construtor de comunicacao com a TelaLogin (view)
	 * @param viewLogin - variavel do tipo TelaLogin para controle da tela
	 */
	public LoginController(TelaLogin viewLogin) {
		this.viewLogin = viewLogin;
		
	}
	
	/**
	 * Metodo para logar o usuario no sistema, busca os dados digitados na tela e compara com o banco de dados
	 * @return mensagem - com o resultado para o usuário
	 */
	public String autenticarUsuario(){
		String mensagem;
		
		String login = viewLogin.getTxtUsuario().getText();
		String senha = new String(viewLogin.getTxtSenha().getPassword());
		
		Funcionarios funcionario = new Funcionarios(login,senha);
		
		FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
		if(funcionarioDAO.autenticarFuncionario(funcionario).equals("Gerente")) {
			mensagem = "Acesso autorizado!"; 
			viewLogin.getFrame().dispose();
			TelaPrincipal telaPrincipal = new TelaPrincipal();
			
		}
		else if(funcionarioDAO.autenticarFuncionario(funcionario).equals("")){
			mensagem = "Usuário ou senha incorretos!";
		}
		else{
			mensagem ="Acesso autorizado!";
			viewLogin.getFrame().dispose();
			TelaPrincipal telaPrincipal = new TelaPrincipal(); //Conforme RN07 - Apenas o usuário com cargo de gerente poderá acessar a funcionalidade de relatórios e cadastro de funcionários.
			telaPrincipal.getBtnFuncionarios().setVisible(false);
			telaPrincipal.getBtnRelatorios().setVisible(false);
		}
		return mensagem;
	}

}
