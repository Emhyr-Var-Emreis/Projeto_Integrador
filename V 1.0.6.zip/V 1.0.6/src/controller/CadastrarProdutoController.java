package controller;

import bancoDeDados.ProdutosDAO;
import model.Produtos;
import view.paineis.PainelCadastrarProdutos;

public class CadastrarProdutoController {

	private final PainelCadastrarProdutos viewCadastroProdutos;
	
	/**
	 * Construtor de comunicacao com o PainelCadastroProdutos (view)
	 * @param viewCadastroProduto - variavel do tipo PainelCadastroProdutos para controle da tela
	 * 
	 */
	public CadastrarProdutoController(PainelCadastrarProdutos viewCadastroProduto) {
		this.viewCadastroProdutos = viewCadastroProduto;
	}
	
	/**
	 * Metodo que busca os valores digitados na tela de cadastro de produtos e aciona o metodo para salvar produto no banco de dados
	 * @return mensagem - retorna uma mensagem do tipo String para o usuário
	 */
	public String salvarProduto() {
		String mensagem;
		try {
			String nome = viewCadastroProdutos.getTxtNome().getText();
			String descricao = viewCadastroProdutos.getTxtDescricao().getText();
			Double valorUnitario = Double.parseDouble(viewCadastroProdutos.getTxtValorUnitario().getText());
			String unidadeMedida = viewCadastroProdutos.getTxtUnidadeMedida().getText();

			if(nome.length()==0) {
				mensagem = "É obrigatório informar um nome para o produto!"; //Conforme RN12
			}
			else if(descricao.length()==0) {
				mensagem = "É obrigatório informar uma descrição para o produto!"; //Conforme RN12
			}
			else if(valorUnitario<=0) {
				mensagem = "Por favor digite um valor unitário valido!"; //Conforme RN12
			}
			else if(unidadeMedida.length()==0) {
				mensagem = "É obrigatório informar uma unidade de medida para o produto!"; //Conforme RN12
			} 
			else {
				Produtos produto = new Produtos(nome, valorUnitario, descricao, unidadeMedida);

				ProdutosDAO produtoDAO = new ProdutosDAO();

				mensagem = produtoDAO.salvarProdutoBanco(produto);
			}
		}
		catch(NumberFormatException erro) {
			mensagem = "Por favor digite um valor unitário valido!";
		}
		return mensagem;
	}

	/**
	 * Metodo que limpa todos os campos da tela
	 */
	public void limpar() {
		viewCadastroProdutos.getTxtNome().setText("");
		viewCadastroProdutos.getTxtDescricao().setText("");
		viewCadastroProdutos.getTxtValorUnitario().setText("");
		viewCadastroProdutos.getTxtUnidadeMedida().setText("");
	}
}
