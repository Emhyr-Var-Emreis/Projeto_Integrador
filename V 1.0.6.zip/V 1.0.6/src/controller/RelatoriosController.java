package controller;


import bancoDeDados.RelatoriosDAO;
import view.paineis.PainelRelatorio;

public class RelatoriosController {
	
	private final PainelRelatorio viewRelatorio;
	
	public RelatoriosController(PainelRelatorio viewRelatorio) {
		this.viewRelatorio = viewRelatorio;
	}
	
	public String gerarRelatorio(String tabela) {
		String mensagem;
		RelatoriosDAO relatorioDAO = new RelatoriosDAO();
		if(tabela.equals("produto")) {
			mensagem = relatorioDAO.exportarProdutoBanco();
		}
		else if (tabela.equals("ordemServico")) {
			mensagem = relatorioDAO.exportarOSBanco();
		}
		else if (tabela.equals("faturamentoProduto")) {
			mensagem = relatorioDAO.exportarFaturamentoProdutoBanco();
		}
		else if (tabela.equals("faturamentoServico")) {
			mensagem = relatorioDAO.exportarFaturamentoServicoBanco();
		}
		else if (tabela.equals("cliente")) {
			mensagem = relatorioDAO.exportarClienteBanco();
		}
		else if (tabela.equals("veiculo")) {
			mensagem = relatorioDAO.exportarVeiculoBanco();
		}
		else if (tabela.equals("funcionario")) {
			mensagem = relatorioDAO.exportarFuncionarioBanco();
		}
		else {
			mensagem = "Não foi possível gerar o relatório";
		}
		return mensagem;
	}
}
